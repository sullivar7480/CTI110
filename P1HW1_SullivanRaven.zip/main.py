user_num = int(input())
user_num_squared = user_num * user_num   # Bug here; fix it when instructed
   
print(user_num_squared)      # Output formatting issue here; fix it when instructed